package com._42q.springboot.rfid.middleware.model;

public class Action {

    private Long id;
    private String url;
    private String status_event;
    private Long antenna_id;
    private String flavor;
    private String authorization;

    public Action() {
    }

    public Action(Long id, String url, String status_event, Long antenna_id, String flavor, String authorization) {
        this.id = id;
        this.url = url;
        this.status_event = status_event;
        this.antenna_id = antenna_id;
        this.flavor = flavor;
        this.authorization = authorization;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getStatus_event() {
        return status_event;
    }

    public void setStatus_event(String status_event) {
        this.status_event = status_event;
    }

    public Long getAntenna_id() {
        return antenna_id;
    }

    public void setAntenna_id(Long antenna_id) {
        this.antenna_id = antenna_id;
    }

    public String getFlavor() {
        return flavor;
    }

    public void setFlavor(String flavor) {
        this.flavor = flavor;
    }

    public String getAuthorization() {
        return authorization;
    }

    public void setAuthorization(String authorization) {
        this.authorization = authorization;
    }

}
