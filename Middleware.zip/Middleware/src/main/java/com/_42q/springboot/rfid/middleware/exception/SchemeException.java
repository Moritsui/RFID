package com._42q.springboot.rfid.middleware.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason="Authorization Scheme Error")
public class SchemeException extends RuntimeException {

}