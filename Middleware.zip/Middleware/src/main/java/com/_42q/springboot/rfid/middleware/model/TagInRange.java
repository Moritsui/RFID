package com._42q.springboot.rfid.middleware.model;

import java.util.Date;
import java.util.List;

public class TagInRange {

    private Long id;
    private String epc;
    private Date viewed_date;
    private Long antenna_id;

    private List<Antenna> antennas;
    
    public TagInRange() {
    }

    public TagInRange(Long id, String epc, Date viewed_date, Long antenna_id) {
        this.id = id;
        this.epc = epc;
        this.viewed_date = viewed_date;
        this.antenna_id = antenna_id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEpc() {
        return epc;
    }

    public void setEpc(String epc) {
        this.epc = epc;
    }

    public Date getViewed_date() {
        return  viewed_date ;
    }

    public void setViewed_date(Date viewed_date) {
        this.viewed_date = viewed_date;
    }

    public Long getAntenna_id() {
        return antenna_id;
    }

    public void setAntenna_id(Long antenna_id) {
        this.antenna_id = antenna_id;
    }
    public List<Antenna> getAntennas() {
        return antennas;
    }

    public void setAntennas(List<Antenna> antennas) {
        this.antennas = antennas;
    }

}
