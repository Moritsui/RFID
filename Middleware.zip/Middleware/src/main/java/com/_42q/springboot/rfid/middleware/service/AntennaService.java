package com._42q.springboot.rfid.middleware.service;

import com._42q.springboot.rfid.middleware.model.Agent;
import com._42q.springboot.rfid.middleware.model.Antenna;
import java.sql.Connection;
import java.util.List;

/**
 * Created by maximiliano_sandoval on 4/2/18.
 */
public interface AntennaService {

    Long createAntenna(Connection connection, Antenna antenna);

    Long readAntenna(Connection connection, Antenna antenna);

    Boolean updateAntenna(Connection connection, Antenna antenna);

    Boolean deleteAntenna(Connection connection, Long antenna_id);

    Integer totalAntennas(Connection connection);

    List<Antenna> getAllAntennas(Connection connection);

    Antenna getAntenaById(Connection connection, Long antenna_id);

}
