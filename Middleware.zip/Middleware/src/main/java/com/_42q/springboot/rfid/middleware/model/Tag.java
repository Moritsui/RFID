package com._42q.springboot.rfid.middleware.model;

import java.sql.Date;

public class Tag {

    private String epc;
    private Date viewed_date;
    private String status;

    public Tag() {
    }

    public Tag(String epc, Date viewed_date, String status) {
        this.epc = epc;
        this.viewed_date = viewed_date;
        this.status = status;
    }

    public String getEpc() {
        return epc;
    }

    public void setEpc(String epc) {
        this.epc = epc;
    }

    public Date getViewed_date() {
        return viewed_date;
    }

    public void setViewed_date(Date viewed_date) {
        this.viewed_date = viewed_date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
