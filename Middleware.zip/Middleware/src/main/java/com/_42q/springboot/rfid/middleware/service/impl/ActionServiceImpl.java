package com._42q.springboot.rfid.middleware.service.impl;

import com._42q.springboot.rfid.middleware.model.Action;
import com._42q.springboot.rfid.middleware.service.ActionService;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

@Service("ActionService")
public class ActionServiceImpl implements ActionService {

    private static final Logger LOG = Logger.getLogger(ActionServiceImpl.class.getName());

    public Long createAction(Connection connection, Action action) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO backend.action (url, status_event, antenna_id, flavor, authorization) VALUES (?,?,?,?,?) RETURNING id");
            statement.setString(1, action.getUrl());
            statement.setString(2, action.getStatus_event());
            statement.setLong(3, action.getAntenna_id());
            statement.setString(4, action.getFlavor());
            statement.setString(5, action.getAuthorization());

            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Create Action: " + e.getMessage());
        }
        return null;
    }

    public Long readAction(Connection connection, Action action) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.action WHERE url = ?");
            statement.setString(1, action.getUrl());
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getLong("id");
            }
        } catch (SQLException e) {
            LOG.warning("Read Action: " + e.getMessage());
        }
        return null;
    }

    public Boolean updateAction(Connection connection, Action action) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE backend.action SET url = ?, status_event = ?, antenna_id = ?, flavor = ?, authorization = ? WHERE id = ?");
            statement.setString(1, action.getUrl());
            statement.setString(2, action.getStatus_event());
            statement.setLong(3, action.getAntenna_id());
            statement.setString(4, action.getFlavor());
            statement.setString(5, action.getAuthorization());
            statement.setLong(6, action.getId());

            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Update Action: " + e.getMessage());
        }
        return false;
    }

    public Boolean deleteAction(Connection connection, Long action_id) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM backend.action WHERE id = ?");
            statement.setLong(1, action_id);
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Delete Action: " + e.getMessage());
        }
        return false;
    }

    @Override
    public Action getActionByAntennaIdAndEvent(Connection connection, Long antenna_id, String action_event) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.action WHERE antenna_id = ? AND status_event = ?");
            statement.setLong(1, antenna_id);
            statement.setString(2, action_event);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Action action = new Action();
                action.setId(resultSet.getLong("id"));
                action.setUrl(resultSet.getString("url"));
                action.setStatus_event(resultSet.getString("status_event"));
                action.setAntenna_id(resultSet.getLong("antenna_id"));
                action.setFlavor(resultSet.getString("flavor"));
                action.setAuthorization(resultSet.getString("authorization"));

                return action;
            }
        } catch (SQLException e) {
            LOG.warning("Get action by antenna and event action: " + e.getMessage());
        }
        return null;
    }

}
