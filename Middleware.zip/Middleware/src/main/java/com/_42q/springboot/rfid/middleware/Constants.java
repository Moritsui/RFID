package com._42q.springboot.rfid.middleware;

public class Constants {

    /** Security Interceptor **/
    public static final String HEADER_AUTHORIZATION = "Authorization";
    public static final String SCHEME_BASIC = "Basic";
    public static final String PASSWORD = "cmVhZGVyczpDcmVkZW50aWFsNDJR";

    /** Tags Rest Controller **/
    public static final String IN_RANGE = "InRange";
    public static final String OUT_RANGE = "OutRange";
    public static final String SPLUNK = "Splunk";
    public static final String DEMO = "Demo";
    public static final String SPLUNK_HOST = "TestServer";
    public static final String SPLUNK_SOURCE = "RFID-Middleware";
    public static final String SPLUNK_INDEX = "rfid";

}
