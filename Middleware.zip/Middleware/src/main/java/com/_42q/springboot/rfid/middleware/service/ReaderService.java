package com._42q.springboot.rfid.middleware.service;

import com._42q.springboot.rfid.middleware.model.Reader;

import java.sql.Connection;
import java.util.List;

/**
 * Created by maximiliano_sandoval on 4/2/18.
 */
public interface ReaderService {

    Long createReader(Connection connection, Reader reader);

    Long readReader(Connection connection, Reader reader);

    Boolean updateReader(Connection connection, Reader reader);

    Boolean deleteReader(Connection connection, Long reader_id);

    List<Reader> findReadersByAgentId(Connection connection, Long agent_id);

    Integer totalReaders(Connection connection);

    List<Reader> getAllReaders(Connection connection);

}
