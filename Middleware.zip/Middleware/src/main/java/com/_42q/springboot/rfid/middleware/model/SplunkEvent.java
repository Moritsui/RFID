package com._42q.springboot.rfid.middleware.model;

import java.util.Date;

public class SplunkEvent {

    private Long agent_id;
    private String agent_name;
    private Long reader_id;
    private String reader_name;
    private Long antenna_id;
    private String antenna_name;
    private String epc;
    private Date viewed_date;
    private String status;

    public SplunkEvent() {
    }

    public SplunkEvent(Long agent_id, String agent_name, Long reader_id, String reader_name, Long antenna_id, String antenna_name, String epc, Date viewed_date, String status) {
        this.agent_id = agent_id;
        this.agent_name = agent_name;
        this.reader_id = reader_id;
        this.reader_name = reader_name;
        this.antenna_id = antenna_id;
        this.antenna_name = antenna_name;
        this.epc = epc;
        this.viewed_date = viewed_date;
        this.status = status;
    }


    public Long getAgent_id() {
        return agent_id;
    }

    public void setAgent_id(Long agent_id) {
        this.agent_id = agent_id;
    }

    public String getAgent_name() {
        return agent_name;
    }

    public void setAgent_name(String agent_name) {
        this.agent_name = agent_name;
    }

    public Long getReader_id() {
        return reader_id;
    }

    public void setReader_id(Long reader_id) {
        this.reader_id = reader_id;
    }

    public String getReader_name() {
        return reader_name;
    }

    public void setReader_name(String reader_name) {
        this.reader_name = reader_name;
    }

    public Long getAntenna_id() {
        return antenna_id;
    }

    public void setAntenna_id(Long antenna_id) {
        this.antenna_id = antenna_id;
    }

    public String getAntenna_name() {
        return antenna_name;
    }

    public void setAntenna_name(String antenna_name) {
        this.antenna_name = antenna_name;
    }

    public String getEpc() {
        return epc;
    }

    public void setEpc(String epc) {
        this.epc = epc;
    }

    public Date getViewed_date() {
        return viewed_date;
    }

    public void setViewed_date(Date viewed_date) {
        this.viewed_date = viewed_date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
