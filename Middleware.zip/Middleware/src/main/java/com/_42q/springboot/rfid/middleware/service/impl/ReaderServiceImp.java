package com._42q.springboot.rfid.middleware.service.impl;

import com._42q.springboot.rfid.middleware.model.Reader;
import com._42q.springboot.rfid.middleware.service.ReaderService;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;


@Service("ReaderService")
public class ReaderServiceImp implements ReaderService {

    private static final Logger LOG = Logger.getLogger(ReaderServiceImp.class.getName());

    public Long createReader(Connection connection, Reader reader) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO backend.reader (name, ip, read_time, stop_time, agent_id, reader_connect, reader_active) VALUES (?,?,?,?,?,?,?) RETURNING id");
            statement.setString(1, reader.getName().toLowerCase());
            statement.setString(2, reader.getIp());
            statement.setString(3, reader.getRead_time());
            statement.setString(4, reader.getStop_time());
            statement.setLong(5, reader.getAgent_id());
            statement.setBoolean(6, reader.isReader_connect());
            statement.setBoolean(7, reader.isReader_active());

            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Create Reader: " + e.getMessage());
        }
        return null;
    }

    public Long readReader(Connection connection, Reader reader) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT id FROM backend.reader WHERE agent_id = ? AND  name = ?");
            statement.setLong(1, reader.getAgent_id());
            statement.setString(2, reader.getName().toLowerCase());
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Read Reader: " + e.getMessage());
        }
        return null;
    }

    public Boolean updateReader(Connection connection, Reader reader) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE backend.reader SET name = ?, ip = ?, read_time = ?, stop_time = ?, reader_connect = ?, reader_active = ? WHERE id = ?");
            statement.setString(1, reader.getName().toLowerCase());
            statement.setString(2, reader.getIp());
            statement.setString(3, reader.getRead_time());
            statement.setString(4, reader.getStop_time());
            statement.setBoolean(5, reader.isReader_connect());
            statement.setBoolean(6, reader.isReader_active());
            statement.setLong(7, reader.getId());
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Update Reader: " + e.getMessage());
        }
        return false;
    }

    public Boolean deleteReader(Connection connection, Long reader_id) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM backend.reader WHERE id = ?");
            statement.setLong(1, reader_id);
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Delete Antenna: " + e.getMessage());
        }
        return false;
    }

    public List<Reader> findReadersByAgentId(Connection connection, Long agent_id) {

        List<Reader> readers = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.reader WHERE agent_id = ?");
            statement.setLong(1, agent_id);

            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()) {
                Reader reader = new Reader();

                reader.setId(resultSet.getLong("id"));
                reader.setName(resultSet.getString("name"));
                reader.setIp(resultSet.getString("ip"));
                reader.setRead_time(resultSet.getString("read_time"));
                reader.setStop_time(resultSet.getString("stop_time"));
                reader.setAgent_id(resultSet.getLong("agent_id"));
                reader.setReader_connect(resultSet.getBoolean("reader_connect"));
                reader.setReader_active(resultSet.getBoolean("reader_active"));
                readers.add(reader);
            }

            return readers;
        } catch (SQLException e) {
            LOG.warning("Find Readers By Agent Id: " + e.getMessage());
        }
        return null;
    }

    @Override
    public Integer totalReaders(Connection connection) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM backend.reader");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("count");
            }
        } catch (SQLException e) {
            LOG.warning("Total Readers: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Reader> getAllReaders(Connection connection) {
        List<Reader> readers = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.reader");
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()) {
                Reader reader = new Reader();

                reader.setId(resultSet.getLong("id"));
                reader.setName(resultSet.getString("name"));
                reader.setIp(resultSet.getString("ip"));
                reader.setRead_time(resultSet.getString("read_time"));
                reader.setStop_time(resultSet.getString("stop_time"));
                reader.setAgent_id(resultSet.getLong("agent_id"));
                reader.setReader_connect(resultSet.getBoolean("reader_connect"));
                reader.setReader_active(resultSet.getBoolean("reader_active"));
                readers.add(reader);
            }

            return readers;
        } catch (SQLException e) {
            LOG.warning("Get all readers " + e.getMessage());
        }
        return null;

    }

}
