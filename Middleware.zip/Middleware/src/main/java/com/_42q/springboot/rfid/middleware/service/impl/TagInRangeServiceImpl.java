package com._42q.springboot.rfid.middleware.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com._42q.springboot.rfid.middleware.model.TagInRange;
import com._42q.springboot.rfid.middleware.service.TagInRangeService;

@Service("TagInRangeService")
public class TagInRangeServiceImpl implements TagInRangeService {

	private static final Logger LOG = Logger.getLogger(TagInRangeServiceImpl.class.getName());

	public Long createTagInRange(Connection connection, TagInRange tagInRange) {
		try {
			PreparedStatement statement = connection.prepareStatement(
					"INSERT INTO backend.tag_in_range (epc, viewed_date, antenna_id) VALUES (?,?,?) RETURNING id");
			statement.setString(1, tagInRange.getEpc());
			////// date//////

			java.util.Date utilDate = tagInRange.getViewed_date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(utilDate);
			cal.set(Calendar.MILLISECOND, 0);
			System.out.println(new java.sql.Timestamp(utilDate.getTime()));
			System.out.println(new java.sql.Timestamp(cal.getTimeInMillis()));

			statement.setTimestamp(2, new java.sql.Timestamp(tagInRange.getViewed_date().getTime()));
			// statement.setTimestamp(2, new Timestamp(tagInRange.getViewed_date()));
			statement.setLong(3, tagInRange.getAntenna_id());

			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				return resultSet.getLong(1);
			}
		} catch (SQLException e) {
			LOG.warning("Create TagInRange: " + e.getMessage());
		}
		return null;
	}

	public Long readTagInRange(Connection connection, TagInRange tagInRange) {
		try {
			PreparedStatement statement = connection
					.prepareStatement("SELECT id FROM backend.tag_in_range WHERE antenna_id = ? AND epc = ?");
			statement.setLong(1, tagInRange.getAntenna_id());
			statement.setString(2, tagInRange.getEpc());

			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				return resultSet.getLong(1);
			}
		} catch (SQLException e) {
			LOG.warning("Read TagInRange: " + e.getMessage());
		}
		return null;
	}

	public Boolean updateTagInRange(Connection connection, TagInRange tagInRange) {
		try {
			PreparedStatement statement = connection.prepareStatement(
					"UPDATE backend.tag_in_range SET epc = ?, viewed_date = ?, antenna_id = ? WHERE id = ?");
			statement.setString(1, tagInRange.getEpc());
			////// date//////

			java.util.Date utilDate = tagInRange.getViewed_date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(utilDate);
			cal.set(Calendar.MILLISECOND, 0);
			// statement.setDate(2, tagInRange.getViewed_date());
			statement.setTimestamp(2, new java.sql.Timestamp(tagInRange.getViewed_date().getTime()));
			statement.setLong(3, tagInRange.getAntenna_id());
			statement.setLong(4, tagInRange.getId());

			statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			LOG.warning("Update TagInRange: " + e.getMessage());
		}
		return false;
	}

	public Boolean deleteTagInRange(Connection connection, Long tagInRange_id) {
		try {
			PreparedStatement statement = connection.prepareStatement("DELETE FROM backend.tag_in_range WHERE id = ?");
			statement.setLong(1, tagInRange_id);

			statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			LOG.warning("Delete TagInRange: " + e.getMessage());
		}
		return false;
	}

	@Override
	public Integer totalTagsInRange(Connection connection) {
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM backend.tag_in_range");
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				return resultSet.getInt("count");
			}
		} catch (SQLException e) {
			LOG.warning("Total Tags in range: " + e.getMessage());
		}
		return null;
	}

	@Override
	public List<TagInRange> getAllTagInRangess(Connection connection) {
		List<TagInRange> TagInRanges = new ArrayList<>();
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.tag_in_range");
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				TagInRange tagEnRango = new TagInRange();
				tagEnRango.setId(resultSet.getLong("id"));
				tagEnRango.setEpc(resultSet.getString("epc"));
				tagEnRango.setViewed_date(resultSet.getTimestamp("viewed_date"));
				tagEnRango.setAntenna_id(resultSet.getLong("antenna_id"));

				TagInRanges.add(tagEnRango);
				//System.out.println("hola->" + tagEnRango.getViewed_date().toString());
			}
			return TagInRanges;
		} catch (SQLException e) {
			LOG.warning("Get all TagInRange" + e.getMessage());
		}
		return null;
	}

}
