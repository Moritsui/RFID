package com._42q.springboot.rfid.middleware.controller;

import com._42q.springboot.rfid.middleware.model.Agent;
import com._42q.springboot.rfid.middleware.model.Antenna;
import com._42q.springboot.rfid.middleware.model.Reader;
import com._42q.springboot.rfid.middleware.model.Resource;
import com._42q.springboot.rfid.middleware.model.SplunkEvent;
import com._42q.springboot.rfid.middleware.model.Tag;
import com._42q.springboot.rfid.middleware.model.TagInRange;
import com._42q.springboot.rfid.middleware.service.*;
import com._42q.springboot.rfid.middleware.util.ConnectionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by maximiliano_sandoval on 3/5/18.
 */
@Controller
@RequestMapping(value = "/dashboard")
public class DashboardController {

    private static final Logger LOG = Logger.getLogger(DashboardController.class.getName());

    @Autowired
    private DataSource dataSource;

    @Autowired
    private AgentService agentService;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private AntennaService antennaService;
    @Autowired
    private TagInRangeService tagInRangeService;
    @Autowired
    private TagMovementInformationService tagMovementInformationService;



    @RequestMapping(method = RequestMethod.GET)
    public String sessionStart(Model model) {

        Connection connection = ConnectionHandler.getConnection(dataSource);

        initDashboard(connection, model);

        ConnectionHandler.releaseConnection(connection);
        return "dashboard";
    }
   //////////////////////Eliminar/////////////////////////////////
    /*@RequestMapping(value = "/delete/{element}/{id}", method = RequestMethod.GET)
    public String deleteTagInRange(Model model,@PathVariable Long id) {
    	
    	
		return null;
    	
    } */
    
    @RequestMapping(value = "/update/{element}/{id}", method = RequestMethod.PUT)
    public String updateAntenna(Model model, @PathVariable String element, @PathVariable Long id, @RequestParam("active") Boolean active) {

        Connection connection = ConnectionHandler.getConnection(dataSource);

        switch (element) {
            case "agent":
                break;

            case "reader":
                break;

            case "antenna":

                Antenna antenna = antennaService.getAntenaById(connection, id);
                antenna.setAntenna_active(active);

                antennaService.updateAntenna(connection, antenna);

                break;

            default:

                break;
        }

        initDashboard(connection, model);

        return "dashboard";
    }

    private void initDashboard(Connection connection, Model model) {

        model.addAttribute("actionExceptions", tagMovementInformationService.totalExceptions(connection));
        model.addAttribute("totalAgents", agentService.totalAgents(connection));
        model.addAttribute("totalReaders", readerService.totalReaders(connection));
        model.addAttribute("totalAntennas", antennaService.totalAntennas(connection));
        model.addAttribute("totalActiveTags", tagInRangeService.totalTagsInRange(connection));
        model.addAttribute("totalenRango", tagInRangeService.getAllTagInRangess(connection));
        

        List<Agent> agentList = agentService.getAllAgents(connection);
        List<Reader> readerList = readerService.getAllReaders(connection);
        List<Antenna> antennaList = antennaService.getAllAntennas(connection);
        List<TagInRange> tagInRangeList = tagInRangeService.getAllTagInRangess(connection);
        
        List<SplunkEvent> resourceList3 = new ArrayList<>();
        SplunkEvent resource3 = new SplunkEvent();
        
        List<Resource> resourceList = new ArrayList<>();
        Resource resource = new Resource();
        
        List<TagInRange> resourceList2 = new ArrayList<>();
        TagInRange resource2 = new TagInRange();
        
                
        
         //////////////SplunkEvenet///////////////////
        
        for (Agent agent : agentList) {
        	resource3.setAgent_id(agent.getId());
        	resource3.setAgent_name(agent.getName());
        	
        }
        for(Antenna antena : antennaList) {
        	for(Reader reader :  readerList) {
        		if(reader.getId().equals(antena.getReader_id())) {
        			resource3.setReader_id(reader.getId());
        			resource3.setReader_name(reader.getName());
        		}
        	}
        	for(TagInRange tagInRange : tagInRangeList) {
        		resource3.setEpc(tagInRange.getEpc());
        		resource3.setViewed_date(tagInRange.getViewed_date());
        		
        		
        	}
        	resource3.setAntenna_id(antena.getId());
        	resource3.setAntenna_name(antena.getName());
        	resourceList3.add(resource3);
        	resource3 = new SplunkEvent();
        }
        //////////////////////////////////////////////
        for (TagInRange tagInRange : tagInRangeList) {
        	resource2.setId(tagInRange.getId());
        	resource2.setEpc(tagInRange.getEpc());
        	resource2.setViewed_date(tagInRange.getViewed_date());
        	resource2.setAntenna_id(tagInRange.getAntenna_id());
        	resourceList2.add(resource2);
        	resource2 = new TagInRange();
        	
        }
       
        for (Antenna antenna : antennaList) {
            for (Reader reader : readerList) {
            	
                if (reader.getId().equals(antenna.getReader_id())) {
                    resource.setReaderName(reader.getName());
                    resource.setIp(reader.getIp());
                    
                 
                }
            }
           

            resource.setAntennaName(antenna.getName());
            resource.setAntennaID(antenna.getId());
            resource.setAntennaStatus(antenna.isAntenna_active());
            resource.setAntennaConnected(antenna.isAntenna_connect());
            resource.setPort(antenna.getPort());
            resourceList.add(resource);
            resource = new Resource();
            
           
            
        }

        model.addAttribute("resourcesList", resourceList);
        
        model.addAttribute("resourcesList2", resourceList2);
        
        model.addAttribute("resourceList3", resourceList3);
    }

}
