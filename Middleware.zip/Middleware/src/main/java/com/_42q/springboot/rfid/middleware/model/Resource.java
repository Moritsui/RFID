package com._42q.springboot.rfid.middleware.model;

/**
 * Created by maximiliano_sandoval for 42Q cloud MES solutions.
 */
public class Resource {

    private String readerName;
    private String ip;
    private String antennaName;
    private Long antennaID;
    private Boolean antennaStatus;
    private Boolean antennaConnected;
    private String port;

    public Resource() {
    }

    public Resource(String readerName, String ip, String antennaName, Long antennaID, Boolean antennaStatus, Boolean antennaConnected, String port) {
        this.readerName = readerName;
        this.ip = ip;
        this.antennaName = antennaName;
        this.antennaID = antennaID;
        this.antennaStatus = antennaStatus;
        this.antennaConnected = antennaConnected;
        this.port = port;
    }

    public String getReaderName() {
        return readerName;
    }

    public void setReaderName(String readerName) {
        this.readerName = readerName;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getAntennaName() {
        return antennaName;
    }

    public void setAntennaName(String antennaName) {
        this.antennaName = antennaName;
    }

    public Long getAntennaID() {
        return antennaID;
    }

    public void setAntennaID(Long antennaID) {
        this.antennaID = antennaID;
    }

    public Boolean getAntennaStatus() {
        return antennaStatus;
    }

    public void setAntennaStatus(Boolean antennaStatus) {
        this.antennaStatus = antennaStatus;
    }

    public Boolean getAntennaConnected() {
        return antennaConnected;
    }

    public void setAntennaConnected(Boolean antennaConnected) {
        this.antennaConnected = antennaConnected;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }
}
