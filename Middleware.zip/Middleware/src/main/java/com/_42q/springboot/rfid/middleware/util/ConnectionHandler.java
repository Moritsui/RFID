package com._42q.springboot.rfid.middleware.util;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

public class ConnectionHandler {

    private static final Logger LOG = Logger.getLogger(ConnectionHandler.class.getName());

    public static Connection getConnection(DataSource dataSource) {
        Connection connection = null;
        try {
            connection = dataSource.getConnection();
        } catch (SQLException e) {
            LOG.warning("SQLException: "+ e.getMessage());
        }
        return connection;
    }
    public static void releaseConnection(Connection connection) {
        try {
            connection.close();
        } catch (SQLException e) {
            LOG.warning("SQLException: "+ e.getMessage());
        }
    }
}
