package com._42q.springboot.rfid.middleware.service;

import com._42q.springboot.rfid.middleware.model.Action;

import java.sql.Connection;

public interface ActionService {

    Long createAction(Connection connection, Action action);

    Long readAction(Connection connection, Action action);

    Boolean updateAction(Connection connection, Action action);

    Boolean deleteAction(Connection connection, Long action_id);

    Action getActionByAntennaIdAndEvent(Connection connection, Long antenna_id, String action_event);

}
