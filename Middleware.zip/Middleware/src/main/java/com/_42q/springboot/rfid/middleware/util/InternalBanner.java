package com._42q.springboot.rfid.middleware.util;

import org.springframework.boot.Banner;
import org.springframework.core.env.Environment;

import java.io.PrintStream;
import java.lang.management.ManagementFactory;

/**
 * Created by maximiliano_sandoval on 2/13/18.
 */
public class InternalBanner implements Banner {

    @Override
    public void printBanner(Environment environment, Class<?> aClass, PrintStream printStream) {
        printStream.println("\n" +
                "    :::      ::::::::   ::::::::   \n" +
                "   :+:      :+:    :+: :+:    :+:  \n" +
                "  +:+ +:+         +:+  +:+    +:+  \n" +
                " +#+  +:+       +#+    +#+    +:+  \n" +
                "+#+#+#+#+#+   +#+      +#+  # +#+  \n" +
                "      #+#    #+#       #+#   +#+   \n" +
                "      ###   ##########  ###### ### \n");

        printStream.println("|>>> Process Id : " + ManagementFactory.getRuntimeMXBean().getName());

    }
}
