package com._42q.springboot.rfid.middleware.model;

import java.util.List;

/**
 * Created by maximiliano_sandoval on 3/9/18.
 */
public class Reader {

    private Long id;
    private String name;
    private String ip;
    private String read_time;
    private String stop_time;
    private Long agent_id;
    private boolean reader_connect;
    private boolean reader_active;

    private List<Antenna> antennas;

    public Reader() {
    }

    public Reader(Long id, String name, String ip, String read_time, String stop_time, Long agent_id, boolean reader_connect, boolean reader_active, List<Antenna> antennas) {
        this.id = id;
        this.name = name;
        this.ip = ip;
        this.read_time = read_time;
        this.stop_time = stop_time;
        this.agent_id = agent_id;
        this.reader_connect = reader_connect;
        this.reader_active = reader_active;
        this.antennas = antennas;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getRead_time() {
        return read_time;
    }

    public void setRead_time(String read_time) {
        this.read_time = read_time;
    }

    public String getStop_time() {
        return stop_time;
    }

    public void setStop_time(String stop_time) {
        this.stop_time = stop_time;
    }

    public Long getAgent_id() {
        return agent_id;
    }

    public void setAgent_id(Long agent_id) {
        this.agent_id = agent_id;
    }

    public boolean isReader_connect() {
        return reader_connect;
    }

    public void setReader_connect(boolean reader_connect) {
        this.reader_connect = reader_connect;
    }

    public boolean isReader_active() {
        return reader_active;
    }

    public void setReader_active(boolean reader_active) {
        this.reader_active = reader_active;
    }

    public List<Antenna> getAntennas() {
        return antennas;
    }

    public void setAntennas(List<Antenna> antennas) {
        this.antennas = antennas;
    }

}