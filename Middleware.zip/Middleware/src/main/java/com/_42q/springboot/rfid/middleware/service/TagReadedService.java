package com._42q.springboot.rfid.middleware.service;

import com._42q.springboot.rfid.middleware.model.TagReaded;
import java.sql.Connection;

public interface TagReadedService {

    Long createTagReaded(Connection connection, TagReaded tagReaded);

    Long readTagReaded(Connection connection, TagReaded tagReaded);

    Boolean updateTagReaded(Connection connection, TagReaded tagReaded);

    Boolean deleteTagReaded(Connection connection, Long tagReaded_id);

}
