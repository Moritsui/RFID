package com._42q.springboot.rfid.middleware.controller;

import com._42q.springboot.rfid.middleware.model.Agent;
import com._42q.springboot.rfid.middleware.model.Antenna;
import com._42q.springboot.rfid.middleware.model.Reader;
import com._42q.springboot.rfid.middleware.response.BooleanResponse;
import com._42q.springboot.rfid.middleware.service.AgentService;
import com._42q.springboot.rfid.middleware.service.AntennaService;
import com._42q.springboot.rfid.middleware.service.ReaderService;
import com._42q.springboot.rfid.middleware.util.ConnectionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.Connection;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by maximiliano_sandoval on 3/9/18.
 */
@RestController
@RequestMapping("/status/api/v1")
public class AgentStatusRestController {

    private static final Logger LOG = Logger.getLogger(AgentStatusRestController.class.getName());
    private StringBuilder reportLog = new StringBuilder();
    @Autowired
    private DataSource dataSource;
    @Autowired
    private AgentService agentService;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private AntennaService antennaService;


    @RequestMapping(value = "/agent", method = RequestMethod.POST)
    public BooleanResponse success(HttpServletRequest request, @RequestBody Agent agentBody) {
        LOG.info("/status/api/v1/agents POST");
        BooleanResponse booleanResponse = new BooleanResponse(false);

        Connection connection = ConnectionHandler.getConnection(dataSource);
        Long agentId = agentService.readAgent(connection,agentBody);

        if (agentId != null){
            reportLog.append("[Updating Agent] ").append(agentBody.getName().toLowerCase()).append(":").append(agentId).append(" ");
            agentBody.setId(agentId);

            if (agentService.updateAgent(connection, agentBody)) {
                List<Reader> readers = agentBody.getReaders();

                for (Reader reader : readers) {
                    reader.setAgent_id(agentId);
                    Long readerId = readerService.readReader(connection, reader);

                    if (readerId != null) {
                        reportLog.append("[Updating Reader] ").append(reader.getName().toLowerCase()).append(":").append(readerId).append(" ");
                        reader.setId(readerId);

                        if (readerService.updateReader(connection, reader)) {
                            List<Antenna> antennas = reader.getAntennas();

                            for (Antenna antenna : antennas) {
                                antenna.setReader_id(readerId);
                                Long antennaId = antennaService.readAntenna(connection, antenna);

                                if (antennaId != null) {
                                    reportLog.append("[Updating Antennas] ").append(antenna.getName().toLowerCase()).append(":").append(antennaId).append(" ");
                                    antenna.setId(antennaId);

                                    if (antennaService.updateAntenna(connection, antenna)) {

                                        /* Actualizado */

                                    } else {
                                        /* Error al actualizar la antenna */
                                    }
                                } else  {
                                    /* La antena no existe en la base, debe guardarse */
                                    antennaId = antennaService.createAntenna(connection, antenna);
                                    reportLog.append("[Creating Antennas] ").append(antenna.getName().toLowerCase()).append(":").append(antennaId).append(" ");
                                }
                            }
                        } else {
                            /* Error al actualizar el reader */
                        }

                    } else {
                        readerId = readerService.createReader(connection, reader);
                        reportLog.append("[Creating Reader] ").append(reader.getName().toLowerCase()).append(":").append(readerId).append(" ");

                        if (readerId != null) {
                            List<Antenna> antennas = reader.getAntennas();
                            for (Antenna antenna : antennas) {
                                antenna.setReader_id(readerId);
                                Long antennaId = antennaService.createAntenna(connection, antenna);
                            }
                        }
                    }
                }
            } else {
                /* Error al actualizar el agente */
            }
        } else {
            reportLog.append("[Creating Agent] ");
            agentId = agentService.createAgent(connection, agentBody);
            reportLog.append(agentBody.getName().toLowerCase()).append(":").append(agentId).append(" ");

            if (agentId != null){
                List<Reader> readers = agentBody.getReaders();
                reportLog.append("[Creating Reader] ");

                for (Reader reader : readers) {
                    reader.setAgent_id(agentId);
                    Long readerId = readerService.createReader(connection, reader);
                    reportLog.append(reader.getName().toLowerCase()).append(":").append(readerId).append(" ");

                    if (readerId != null){
                        List<Antenna> antennas = reader.getAntennas();
                        reportLog.append("[Creating Antennas] ");

                        for (Antenna antenna : antennas) {
                            antenna.setReader_id(readerId);
                            Long antennaId = antennaService.createAntenna(connection, antenna);
                            reportLog.append(antenna.getName().toLowerCase()).append(":").append(antennaId).append(" ");
                        }
                    }
                }
            }
        }
        booleanResponse.setSuccess(true);
        LOG.info(reportLog.toString());
        reportLog.delete(0, reportLog.length());
        ConnectionHandler.releaseConnection(connection);
        return booleanResponse;
    }

}
