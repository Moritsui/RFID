package com._42q.springboot.rfid.middleware.model;

import java.util.List;

/**
 * Created by maximiliano_sandoval on 3/9/18.
 */
public class Agent {

    private Long id;
    private String name;
    private String ip;
    private String port;
    private boolean agent_active;
    private boolean agent_connect;

    private List<Reader> readers;

    public Agent() {
    }

    public Agent(Long id, String name, String ip, String port, boolean agent_active, boolean agent_connect, List<Reader> readers) {
        this.id = id;
        this.name = name;
        this.ip = ip;
        this.port = port;
        this.agent_active = agent_active;
        this.agent_connect = agent_connect;
        this.readers = readers;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public boolean isAgent_active() {
        return agent_active;
    }

    public void setAgent_active(boolean agent_active) {
        this.agent_active = agent_active;
    }

    public boolean isAgent_connect() {
        return agent_connect;
    }

    public void setAgent_connect(boolean agent_connect) {
        this.agent_connect = agent_connect;
    }

    public List<Reader> getReaders() {
        return readers;
    }

    public void setReaders(List<Reader> readers) {
        this.readers = readers;
    }

}