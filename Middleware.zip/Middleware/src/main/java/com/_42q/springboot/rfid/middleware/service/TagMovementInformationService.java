package com._42q.springboot.rfid.middleware.service;

import com._42q.springboot.rfid.middleware.model.TagMovementInformation;
import com._42q.springboot.rfid.middleware.response.BooleanResponse;

import java.sql.Connection;

public interface TagMovementInformationService {

    Long createTagMovementInformationInRangeAction(Connection connection, TagMovementInformation tagMovementInformation);

    Boolean createTagMovementInformationOutRange(Connection connection, TagMovementInformation tagMovementInformation);

    Long createTagMovementInformation(Connection connection, TagMovementInformation tagMovementInformation);

    TagMovementInformation readTagMovementInformation(Connection connection, TagMovementInformation tagMovementInformation);

    Boolean updateTagMovementInformation(Connection connection, TagMovementInformation tagMovementInformation);

    Boolean deleteTagMovementInformation(Connection connection, Long tagMovementInformation_id);

    Integer totalExceptions(Connection connection);

}
