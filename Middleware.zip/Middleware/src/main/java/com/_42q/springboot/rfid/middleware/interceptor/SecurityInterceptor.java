package com._42q.springboot.rfid.middleware.interceptor;

import com._42q.springboot.rfid.middleware.Constants;
import com._42q.springboot.rfid.middleware.exception.SchemeException;
import com._42q.springboot.rfid.middleware.exception.UnauthorizedException;
import org.springframework.lang.Nullable;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;
import java.util.logging.Logger;

/**
 * Created by maximiliano_sandoval on 3/9/18.
 */
public class SecurityInterceptor implements HandlerInterceptor {

    private static final Logger LOG = Logger.getLogger(SecurityInterceptor.class.getName());

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String basicCredential = request.getHeader(Constants.HEADER_AUTHORIZATION);

        if (!basicCredential.contains(Constants.SCHEME_BASIC)){
            throw new SchemeException();
        }

        basicCredential = basicCredential.replace(Constants.SCHEME_BASIC + " ", "");

        if (!Objects.equals(basicCredential, Constants.PASSWORD)) {
            throw new UnauthorizedException();
        }

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) throws Exception {

    }

}
