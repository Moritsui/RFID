package com._42q.springboot.rfid.middleware.service;

import com._42q.springboot.rfid.middleware.model.Antenna;
import com._42q.springboot.rfid.middleware.model.TagInRange;

import java.sql.Connection;
import java.util.List;

public interface TagInRangeService {

    Long createTagInRange(Connection connection, TagInRange tagInRange);

    Long readTagInRange(Connection connection, TagInRange tagInRange);

    Boolean updateTagInRange(Connection connection, TagInRange tagInRange);

    Boolean deleteTagInRange(Connection connection, Long tagInRange_id);

    Integer totalTagsInRange(Connection connection);


	List<TagInRange> getAllTagInRangess(Connection connection);

	
    
   

}
