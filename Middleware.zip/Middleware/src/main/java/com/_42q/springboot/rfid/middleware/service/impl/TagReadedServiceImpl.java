package com._42q.springboot.rfid.middleware.service.impl;

import com._42q.springboot.rfid.middleware.model.TagReaded;
import com._42q.springboot.rfid.middleware.service.TagReadedService;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.logging.Logger;

@Service("TagReadedService")
public class TagReadedServiceImpl implements TagReadedService{

    private static final Logger LOG = Logger.getLogger(TagReadedServiceImpl.class.getName());

    public Long createTagReaded(Connection connection, TagReaded tagReaded) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO backend.tag_readed (epc, readed_date, antenna_id) VALUES (?,?,?) RETURNING id");
            statement.setString(1, tagReaded.getEpc());
            //statement.setTimestamp(2, new Timestamp(tagReaded.getReaded_date()));
            statement.setDate(2, tagReaded.getReaded_date());
            statement.setLong(3, tagReaded.getAntenna_id());

            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Create TagReaded: " + e.getMessage());
        }
        return null;
    }

    public Long readTagReaded(Connection connection, TagReaded tagReaded) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT id FROM backend.tag_readed WHERE antenna_id = ? AND epc = ?");
            statement.setLong(1, tagReaded.getAntenna_id());
            statement.setString(2, tagReaded.getEpc());

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Read TagReaded: " + e.getMessage());
        }
        return null;
    }

    public Boolean updateTagReaded(Connection connection, TagReaded tagReaded) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE backend.tag_readed SET epc = ?, readed_date = ?, antenna_id = ? WHERE id = ?");
            statement.setString(1, tagReaded.getEpc());
            //statement.setTimestamp(2, new Timestamp(tagReaded.getReaded_date()));
            statement.setDate(2, tagReaded.getReaded_date());
            statement.setLong(3, tagReaded.getAntenna_id());
            statement.setLong(4, tagReaded.getId());

            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Update TagReaded: " + e.getMessage());
        }
        return false;
    }

    public Boolean deleteTagReaded(Connection connection, Long tagReaded_id) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM backend.tag_readed WHERE id = ?");
            statement.setLong(1, tagReaded_id);

            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Delete TagReaded: " + e.getMessage());
        }
        return false;
    }

}
