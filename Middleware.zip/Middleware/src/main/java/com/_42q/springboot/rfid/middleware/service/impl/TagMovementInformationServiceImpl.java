package com._42q.springboot.rfid.middleware.service.impl;

import com._42q.springboot.rfid.middleware.model.TagMovementInformation;
import com._42q.springboot.rfid.middleware.service.TagMovementInformationService;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.logging.Logger;

@Service("TagMovementInformationService")
public class TagMovementInformationServiceImpl implements TagMovementInformationService {

    private static final Logger LOG = Logger.getLogger(TagMovementInformation.class.getName());

    public Long createTagMovementInformationInRangeAction(Connection connection, TagMovementInformation tagMovementInformation) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO backend.tag_movement_information (viewed_date, action_in_range_id, action_in_range_finished, antenna_id, epc) VALUES (?,?,?,?,?) RETURNING id");
            //statement.setTimestamp(1, new Timestamp(tagMovementInformation.getViewed_date()));
            statement.setDate(1, tagMovementInformation.getViewed_date());
            statement.setLong(2 , tagMovementInformation.getAction_in_range_id());
            statement.setBoolean(3, tagMovementInformation.isAction_in_range_finished());
            statement.setLong(4, tagMovementInformation.getAntenna_id());
            statement.setString(5, tagMovementInformation.getEpc());

            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Create TagMovementInformationInRangeAction: " + e.getMessage());
        }
        return null;
    }

    @Override
    public Boolean createTagMovementInformationOutRange(Connection connection, TagMovementInformation tagMovementInformation) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO backend.tag_movement_information (readed_date, action_readed_id, action_readed_finished, antenna_id, epc, done) VALUES (?,?,?,?,?,?) RETURNING id");
            //statement.setTimestamp(1, new Timestamp(tagMovementInformation.getReaded_date()));
            statement.setDate(1, tagMovementInformation.getViewed_date());
            statement.setLong(2, tagMovementInformation.getAction_readed_id());
            statement.setBoolean(3, tagMovementInformation.isAction_readed_finished());
            statement.setLong(4, tagMovementInformation.getAntenna_id());
            statement.setString(5, tagMovementInformation.getEpc());
            statement.setBoolean(6, tagMovementInformation.isDone());

            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Update TagMovementInformation: " + e.getMessage());
        }
        return false;
    }

    public Long createTagMovementInformation(Connection connection, TagMovementInformation tagMovementInformation) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO backend.tag_movement_information (viewed_date, action_in_range_id, action_in_range_finished, readed_date, action_readed_id, action_readed_finished, antenna_id, epc, done) VALUES (?,?,?,?,?,?,?,?,?) RETURNING id");
            //statement.setTimestamp(1, new Timestamp(tagMovementInformation.getViewed_date()));
            statement.setDate(1, tagMovementInformation.getViewed_date());
            statement.setLong(2 , tagMovementInformation.getAction_in_range_id());
            statement.setBoolean(3, tagMovementInformation.isAction_in_range_finished());
            //statement.setTimestamp(4, new Timestamp(tagMovementInformation.getReaded_date()));
            statement.setDate(4, tagMovementInformation.getReaded_date());
            statement.setLong(5, tagMovementInformation.getAction_readed_id());
            statement.setBoolean(6, tagMovementInformation.isAction_readed_finished());
            statement.setLong(7, tagMovementInformation.getAntenna_id());
            statement.setString(8, tagMovementInformation.getEpc());
            statement.setBoolean(9, tagMovementInformation.isDone());

            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Create TagMovementInformation: " + e.getMessage());
        }
        return null;
    }

    public TagMovementInformation readTagMovementInformation(Connection connection, TagMovementInformation tagMovementInformation) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.tag_movement_information WHERE epc = ? AND antenna_id = ? AND done ISNULL");
            statement.setString(1, tagMovementInformation.getEpc());
            statement.setLong(2, tagMovementInformation.getAntenna_id());
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {

                TagMovementInformation movementInformation = new TagMovementInformation();
                movementInformation.setId(resultSet.getLong("id"));
              //  movementInformation.setViewed_date(resultSet.getTimestamp("viewed_date").getTime());
                movementInformation.setViewed_date(resultSet.getDate("viewed_date"));
                movementInformation.setAction_in_range_id(resultSet.getLong("action_in_range_id"));
                movementInformation.setAction_in_range_finished(resultSet.getBoolean("action_in_range_finished"));
//                movementInformation.setReaded_date(resultSet.getTimestamp("readed_date").getTime());
                movementInformation.setReaded_date(resultSet.getDate("readed_date"));
                movementInformation.setAction_readed_id(resultSet.getLong("action_readed_id"));
                movementInformation.setAction_readed_finished(resultSet.getBoolean("action_readed_finished"));
                movementInformation.setAntenna_id(resultSet.getLong("antenna_id"));
                movementInformation.setEpc(resultSet.getString("epc"));
                movementInformation.setDone(resultSet.getBoolean("done"));

                return movementInformation;
            }
        } catch (SQLException e) {
            LOG.warning("Read TagMovementInformation: " + e.getMessage());
        }
        return null;
    }

    public Boolean updateTagMovementInformation(Connection connection, TagMovementInformation tagMovementInformation) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE backend.tag_movement_information SET viewed_date = ?, action_in_range_id = ?, action_in_range_finished = ?, readed_date = ?, action_readed_id = ?, action_readed_finished = ?, antenna_id = ?, epc = ?, done = ? WHERE id = ?");
            //statement.setTimestamp(1, new Timestamp(tagMovementInformation.getViewed_date()));
            statement.setDate(1, tagMovementInformation.getViewed_date());
            statement.setLong(2 , tagMovementInformation.getAction_in_range_id());
            statement.setBoolean(3, tagMovementInformation.isAction_in_range_finished());
            //statement.setTimestamp(4, new Timestamp(tagMovementInformation.getReaded_date()));
            statement.setDate(4, tagMovementInformation.getReaded_date());
            statement.setLong(5, tagMovementInformation.getAction_readed_id());
            statement.setBoolean(6, tagMovementInformation.isAction_readed_finished());
            statement.setLong(7, tagMovementInformation.getAntenna_id());
            statement.setString(8, tagMovementInformation.getEpc());
            statement.setBoolean(9, tagMovementInformation.isDone());
            statement.setLong(10, tagMovementInformation.getId());

            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Update TagMovementInformation: " + e.getMessage());
        }
        return false;
    }

    public Boolean deleteTagMovementInformation(Connection connection, Long tagMovementInformation_id) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM backend.tag_movement_information WHERE id = ?");
            statement.setLong(1, tagMovementInformation_id);

            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Delete TagMovementInformation: " + e.getMessage());
        }
        return false;
    }

    @Override
    public Integer totalExceptions(Connection connection) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM backend.tag_movement_information WHERE action_in_range_finished = FALSE OR action_readed_finished = FALSE");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("count");
            }
        } catch (SQLException e) {
            LOG.warning("Total Exceptions: " + e.getMessage());
        }
        return null;
    }

}
