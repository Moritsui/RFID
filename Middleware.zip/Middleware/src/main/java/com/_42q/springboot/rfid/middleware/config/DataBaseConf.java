package com._42q.springboot.rfid.middleware.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import javax.sql.DataSource;
import org.apache.commons.dbcp.BasicDataSource;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * Created by maximiliano_sandoval on 3/8/18.
 */
@Configuration
@PropertySource(value = "classpath:RFID.properties")
public class DataBaseConf {

    private static final Logger LOG = Logger.getLogger(DataBaseConf.class.getName());

    @Value("${db.driverClassName}")
    private String DATABASE_DRIVE;
    @Value("${db.url}")
    private String DATABASE_URL;
    @Value("${db.port}")
    private String DATABASE_PORT;
    @Value("${db.username}")
    private String DATABASE_USER;
    @Value("${db.password}")
    private String DATABASE_PASS;
    @Value("${db.name}")
    private String DATABASE_NAME;
    @Value("${db.pool.maxActive}")
    private int DATABASE_MAX_ACTIVE;
    @Value("${db.pool.initialSize}")
    private int DATABASE_INITIAL_SIZE;

    @Bean
    public DataSource dataSource(){

        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(DATABASE_DRIVE);
        dataSource.setUrl(DATABASE_URL +":"+ DATABASE_PORT +"/"+ DATABASE_NAME);
        dataSource.setUsername(DATABASE_USER);
        dataSource.setPassword(DATABASE_PASS);
        dataSource.setMaxActive(DATABASE_MAX_ACTIVE);
        dataSource.setInitialSize(DATABASE_INITIAL_SIZE);

        Connection connection;
        try {
            connection = dataSource.getConnection();
            LOG.info("DataBase Connection Status: " + !connection.isClosed() + " In " + DATABASE_URL +":"+ DATABASE_PORT +"/"+ DATABASE_NAME);
            connection.close();
        } catch (SQLException e) {
            LOG.warning("SQLException: " + e.getMessage());
        }

        return dataSource;
    }

}
