package com._42q.springboot.rfid.middleware.util;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.logging.Logger;

public class RequestHandler {

    private static final Logger LOG = Logger.getLogger(RequestHandler.class.getName());
    private static HttpClient httpClient = null;

    private static void setHeaders(HttpPost httpPost) {
        httpPost.addHeader("Accept","application/json");
        httpPost.addHeader("Content-Type","application/json");
    }

    private static void setHeaderWithAuthorization(HttpPost httpPost, String authorization) {
        httpPost.addHeader("Accept","application/json");
        httpPost.addHeader("Content-Type","application/json");
        httpPost.addHeader("Authorization", authorization);
    }

    public static Boolean postToUrl(String url, String authorization, String DataObject) {

        if (httpClient == null) {
            try {
                LOG.info("Post to Url: " + url);

                httpClient = HttpClientBuilder.create().build();

                StringEntity stringEntity = new StringEntity(DataObject);

                HttpPost httpPost = new HttpPost(url);

                if (authorization == null) {
                    setHeaders(httpPost);
                } else {
                    setHeaderWithAuthorization(httpPost, authorization);
                }

                httpPost.setEntity(stringEntity);

                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                LOG.info("Response: " + EntityUtils.toString(entity));

                httpClient = null;
                return true;
            } catch (IOException e) {
                LOG.warning("Http error: " + e.getMessage());
            }
        }
        return false;
    }

}
