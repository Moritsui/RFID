package com._42q.springboot.rfid.middleware.model;

import java.sql.Date;

public class TagReaded {

    private Long id;
    private String epc;
    private Date readed_date;
    private Long antenna_id;

    public TagReaded() {
    }

    public TagReaded(Long id, String epc, Date readed_date, Long antenna_id) {
        this.id = id;
        this.epc = epc;
        this.readed_date = readed_date;
        this.antenna_id = antenna_id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEpc() {
        return epc;
    }

    public void setEpc(String epc) {
        this.epc = epc;
    }

    public Date getReaded_date() {
        return readed_date;
    }

    public void setReaded_date(Date readed_date) {
        this.readed_date = readed_date;
    }

    public Long getAntenna_id() {
        return antenna_id;
    }

    public void setAntenna_id(Long antenna_id) {
        this.antenna_id = antenna_id;
    }
}
