package com._42q.springboot.rfid.middleware.controller;

import com._42q.springboot.rfid.middleware.Constants;
import com._42q.springboot.rfid.middleware.model.*;
import com._42q.springboot.rfid.middleware.response.BooleanResponse;
import com._42q.springboot.rfid.middleware.service.*;
import com._42q.springboot.rfid.middleware.util.ConnectionHandler;
import com._42q.springboot.rfid.middleware.util.RequestHandler;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.Connection;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.logging.Logger;

/**
 * Created by maximiliano_sandoval on 3/9/18.
 */
@RestController
@RequestMapping("/push/api/v1")
public class TagsRestController {

    private static final Logger LOG = Logger.getLogger(TagsRestController.class.getName());
    private StringBuilder reportLog = new StringBuilder();

    @Autowired
    private DataSource dataSource;
    @Autowired
    private AgentService agentService;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private AntennaService antennaService;
    @Autowired
    private TagInRangeService tagInRangeService;
    @Autowired
    private TagReadedService tagReadedService;
    @Autowired
    private TagMovementInformationService tagMovementInformationService;
    @Autowired
    private ActionService actionService;

    @RequestMapping(value = "/tags", method = RequestMethod.POST)
    public BooleanResponse success(@RequestBody Agent agent) {

        BooleanResponse booleanResponse = new BooleanResponse(false);
        Connection connection = ConnectionHandler.getConnection(dataSource);
        reportLog.append("/push/api/v1/tags POST: ");

        Long agentId = agentService.readAgent(connection, agent);
        if (agentId != null) {
            agent.setId(agentId);
            List<Reader> readers = agent.getReaders();

            for (Reader reader : readers) {
                reader.setAgent_id(agentId);
                Long readerId = readerService.readReader(connection, reader);
                reader.setId(readerId);

                if (readerId != null) {
                    List<Antenna> antennas = reader.getAntennas();

                    for (Antenna antenna : antennas) {
                        antenna.setReader_id(readerId);
                        Long antennaId = antennaService.readAntenna(connection, antenna);

                        if (antennaId != null) {
                            reportLog.append("[Antenna] ").append(antenna.getName().toLowerCase()).append(":").append(antennaId).append(" ").append("[Reporting Tags] ");
                            antenna.setId(antennaId);
                            List<Tag> tags = antenna.getTags();

                            for (Tag tag : tags) {

                                tag.setViewed_date(tag.getViewed_date());
                                rute(connection, agent, reader, antenna, tag);
                                reportLog.append(tag.getEpc()).append(" ").append(tag.getStatus()).append(", ");

                            }
                        } else  {
                            /* La antena no existe en la base */
                        }
                    }
                } else {
                    /* El reader no existe en la base */
                }
            }
        } else {
            /* El agente no existe en la base */
        }
        booleanResponse.setSuccess(true);
        LOG.info(reportLog.toString());
        reportLog.delete(0, reportLog.length());
        ConnectionHandler.releaseConnection(connection);

        return booleanResponse;
    }

    private void rute(Connection connection, Agent agent, Reader reader, Antenna antenna, Tag tag) {
        if (tag.getStatus().equals(Constants.IN_RANGE)){

            TagInRange tagInRange = new TagInRange(0L, tag.getEpc(), tag.getViewed_date(), antenna.getId());
            Long tagId = tagInRangeService.readTagInRange(connection, tagInRange);

            if (tagId == null) {

                tagInRangeService.createTagInRange(connection, tagInRange);

                Action action = actionService.getActionByAntennaIdAndEvent(connection, antenna.getId(), tag.getStatus());
                runAction(action, agent, reader, antenna, tag, connection);

            }
        } else if (tag.getStatus().equals(Constants.OUT_RANGE)) {

            TagInRange tagInRange = new TagInRange(0L, tag.getEpc(), tag.getViewed_date(), antenna.getId());
            Long tagId = tagInRangeService.readTagInRange(connection, tagInRange);

            if (tagId != null) {

                TagReaded tagReaded = new TagReaded(0L, tag.getEpc(), tag.getViewed_date(), antenna.getId());

                tagReadedService.createTagReaded(connection, tagReaded);
                tagInRangeService.deleteTagInRange(connection, tagId);

                Action action = actionService.getActionByAntennaIdAndEvent(connection, antenna.getId(), tag.getStatus());
                runAction(action, agent, reader, antenna, tag, connection);

            }
        }
    }


    private void runAction(Action action, Agent agent, Reader reader, Antenna antenna, Tag tag, Connection connection){
        if (!Objects.equals(action, null)) {
            String JsonBody;
            Boolean executeStatus;

            switch (action.getFlavor()){
                case Constants.SPLUNK:
                    SplunkEvent splunkEvent = new SplunkEvent(
                            agent.getId(), agent.getName(),
                            reader.getId(), reader.getName(),
                            antenna.getId(), antenna.getName(),
                            tag.getEpc(), new Date(), tag.getStatus());
                    Splunk splunk = new Splunk(new Date().getTime(), Constants.SPLUNK_HOST, Constants.SPLUNK_SOURCE, Constants.SPLUNK_INDEX, splunkEvent);
                    JsonBody = new JSONObject(splunk).toString();
                    break;

                case Constants.DEMO:
                    SplunkEvent demo = new SplunkEvent(
                            agent.getId(), agent.getName(),
                            reader.getId(), reader.getName(),
                            antenna.getId(), antenna.getName(),
                            tag.getEpc(), new Date(), tag.getStatus());

                    JsonBody = new JSONObject(demo).toString();
                    break;

                default:
                    JsonBody = new JSONObject(tag).toString();
                    break;
            }

            TagMovementInformation movementInformation = new TagMovementInformation();
            movementInformation.setAntenna_id(antenna.getId());
            movementInformation.setEpc(tag.getEpc());
            movementInformation.setAntenna_id(antenna.getId());

            executeStatus = RequestHandler.postToUrl(action.getUrl(), action.getAuthorization(), JsonBody);

            if (tag.getStatus().equals(Constants.IN_RANGE)) {
                movementInformation.setViewed_date(tag.getViewed_date());
                movementInformation.setAction_in_range_id(action.getId());
                movementInformation.setAction_in_range_finished(executeStatus);

                tagMovementInformationService.createTagMovementInformationInRangeAction(connection, movementInformation);

            } else if (tag.getStatus().equals(Constants.OUT_RANGE)) {
                movementInformation.setReaded_date(tag.getViewed_date());
                movementInformation.setAction_readed_id(action.getId());
                movementInformation.setAction_readed_finished(executeStatus);

                TagMovementInformation information = tagMovementInformationService.readTagMovementInformation(connection, movementInformation);

                if (information != null) {

                    movementInformation.setId(information.getId());
                    movementInformation.setViewed_date(information.getViewed_date());
                    movementInformation.setAction_in_range_id(information.getAction_in_range_id());
                    movementInformation.setAction_in_range_finished(information.isAction_in_range_finished());
                    movementInformation.setDone(true);

                    tagMovementInformationService.updateTagMovementInformation(connection, movementInformation);

                } else {

                    movementInformation.setDone(true);
                    tagMovementInformationService.createTagMovementInformationOutRange(connection, movementInformation);

                }
            }

        }
    }

}
