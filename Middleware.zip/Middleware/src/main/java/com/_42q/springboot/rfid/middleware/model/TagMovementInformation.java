package com._42q.springboot.rfid.middleware.model;

import java.sql.Date;

public class TagMovementInformation {

    private Long id;
    private Date viewed_date;
    private Long action_in_range_id;
    private boolean action_in_range_finished;
    private Date readed_date;
    private Long action_readed_id;
    private boolean action_readed_finished;
    private Long antenna_id;
    private String epc;
    private boolean done;

    public TagMovementInformation() {
    }

    public TagMovementInformation(Long id, Date viewed_date, Long action_in_range_id, boolean action_in_range_finished, Date readed_date, Long action_readed_id, boolean action_readed_finished, Long antenna_id, String epc, boolean done) {
        this.id = id;
        this.viewed_date = viewed_date;
        this.action_in_range_id = action_in_range_id;
        this.action_in_range_finished = action_in_range_finished;
        this.readed_date = readed_date;
        this.action_readed_id = action_readed_id;
        this.action_readed_finished = action_readed_finished;
        this.antenna_id = antenna_id;
        this.epc = epc;
        this.done = done;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getViewed_date() {
        return viewed_date;
    }

    public void setViewed_date(Date viewed_date) {
        this.viewed_date = viewed_date;
    }

    public Long getAction_in_range_id() {
        return action_in_range_id;
    }

    public void setAction_in_range_id(Long action_in_range_id) {
        this.action_in_range_id = action_in_range_id;
    }

    public boolean isAction_in_range_finished() {
        return action_in_range_finished;
    }

    public void setAction_in_range_finished(boolean action_in_range_finished) {
        this.action_in_range_finished = action_in_range_finished;
    }

    public Date getReaded_date() {
        return readed_date;
    }

    public void setReaded_date(Date readed_date) {
        this.readed_date = readed_date;
    }

    public Long getAction_readed_id() {
        return action_readed_id;
    }

    public void setAction_readed_id(Long action_readed_id) {
        this.action_readed_id = action_readed_id;
    }

    public boolean isAction_readed_finished() {
        return action_readed_finished;
    }

    public void setAction_readed_finished(boolean action_readed_finished) {
        this.action_readed_finished = action_readed_finished;
    }

    public Long getAntenna_id() {
        return antenna_id;
    }

    public void setAntenna_id(Long antenna_id) {
        this.antenna_id = antenna_id;
    }

    public String getEpc() {
        return epc;
    }

    public void setEpc(String epc) {
        this.epc = epc;
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }
}
