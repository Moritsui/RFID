package com._42q.springboot.rfid.middleware;

import com._42q.springboot.rfid.middleware.interceptor.SecurityInterceptor;
import com._42q.springboot.rfid.middleware.util.InternalBanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
@ComponentScan("com._42q.springboot.rfid.middleware")
public class MiddlewareApplication implements WebMvcConfigurer {

	public static void main(String[] args) {

		SpringApplication springApplication = new SpringApplication(MiddlewareApplication.class);
		springApplication.setBanner(new InternalBanner());
		springApplication.run(args);

	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/").setViewName("index");
		registry.addViewController("/login").setViewName("login");
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new SecurityInterceptor()).addPathPatterns("/status/api/v1/agent");
		registry.addInterceptor(new SecurityInterceptor()).addPathPatterns("/push/api/v1/tags");
	}
}
