package com._42q.springboot.rfid.middleware.response;

/**
 * Created by maximiliano_sandoval on 3/9/18.
 */
public class BooleanResponse {

    private boolean success;

    public BooleanResponse(boolean success) {
        this.success = success;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

}
