package com._42q.springboot.rfid.middleware.model;

import java.util.List;

/**
 * Created by maximiliano_sandoval on 3/9/18.
 */
public class Antenna {

    private Long id;
    private String name;
    private String port;
    private String dbm;
    private Long reader_id;
    private boolean antenna_connect;
    private boolean antenna_active;

    private List<Tag> tags;

    public Antenna() {
    }

    public Antenna(Long id, String name, String port, String dbm, Long reader_id, boolean antenna_connect, boolean antenna_active, List<Tag> tags) {
        this.id = id;
        this.name = name;
        this.port = port;
        this.dbm = dbm;
        this.reader_id = reader_id;
        this.antenna_connect = antenna_connect;
        this.antenna_active = antenna_active;
        this.tags = tags;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getDbm() {
        return dbm;
    }

    public void setDbm(String dbm) {
        this.dbm = dbm;
    }

    public Long getReader_id() {
        return reader_id;
    }

    public void setReader_id(Long reader_id) {
        this.reader_id = reader_id;
    }

    public boolean isAntenna_connect() {
        return antenna_connect;
    }

    public void setAntenna_connect(boolean antenna_connect) {
        this.antenna_connect = antenna_connect;
    }

    public boolean isAntenna_active() {
        return antenna_active;
    }

    public void setAntenna_active(boolean antenna_active) {
        this.antenna_active = antenna_active;
    }

    public List<Tag> getTags() {
        return tags;
    }

    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

}
