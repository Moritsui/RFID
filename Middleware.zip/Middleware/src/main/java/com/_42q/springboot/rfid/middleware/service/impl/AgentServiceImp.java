package com._42q.springboot.rfid.middleware.service.impl;

import com._42q.springboot.rfid.middleware.model.Agent;
import com._42q.springboot.rfid.middleware.model.Reader;
import com._42q.springboot.rfid.middleware.service.AgentService;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by maximiliano_sandoval on 3/20/18.
 */
@Service("AgentService")
public class AgentServiceImp implements AgentService {

    private static final Logger LOG = Logger.getLogger(AgentServiceImp.class.getName());

    public Long createAgent(Connection connection, Agent agent) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO backend.agent (name,ip,port,agent_active,agent_connect) VALUES (?,?,?,?,?) RETURNING id");
            statement.setString(1, agent.getName().toLowerCase());
            statement.setString(2, agent.getIp());
            statement.setString(3, agent.getPort());
            statement.setBoolean(4, agent.isAgent_active());
            statement.setBoolean(5, agent.isAgent_connect());
            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Create Agent: " + e.getMessage());
        }
        return null;
    }

    public Long readAgent(Connection connection, Agent agent){
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.agent WHERE name = ?");
            statement.setString(1, agent.getName().toLowerCase());
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getLong("id");
            }
        } catch (SQLException e) {
            LOG.warning("Read Agent: " + e.getMessage());
        }
        return null;
    }

    public Boolean updateAgent(Connection connection, Agent agent) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE backend.agent SET ip = ?, port = ?, agent_active = ?, agent_connect = ? WHERE id = ?");
            statement.setString(1, agent.getIp());
            statement.setString(2, agent.getPort());
            statement.setBoolean(3, agent.isAgent_active());
            statement.setBoolean(4, agent.isAgent_connect());
            statement.setLong(5, agent.getId());
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Update Agent: " + e.getMessage());
        }
        return false;
    }

    public Boolean deleteAgent(Connection connection, Long agent_id) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM backend.agent WHERE id = ?");
            statement.setLong(1, agent_id);
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Delete Agent: " + e.getMessage());
        }
        return false;
    }

    @Override
    public Integer totalAgents(Connection connection) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM backend.agent");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("count");
            }
        } catch (SQLException e) {
            LOG.warning("Total Agents: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Agent> getAllAgents(Connection connection) {
        List<Agent> agents = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.agent");
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()) {
                Agent agent = new Agent();

                agent.setId(resultSet.getLong("id"));
                agent.setName(resultSet.getString("name"));
                agent.setIp(resultSet.getString("ip"));
                agent.setPort(resultSet.getString("port"));
                agent.setAgent_active(resultSet.getBoolean("agent_active"));
                agent.setAgent_connect(resultSet.getBoolean("agent_connect"));
                agents.add(agent);
            }

            return agents;
        } catch (SQLException e) {
            LOG.warning("Get all agents: " + e.getMessage());
        }
        return null;
    }

}
