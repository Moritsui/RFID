package com._42q.springboot.rfid.middleware.service;

import com._42q.springboot.rfid.middleware.model.Agent;
import com._42q.springboot.rfid.middleware.model.Reader;

import java.sql.Connection;
import java.util.List;

/**
 * Created by maximiliano_sandoval on 3/20/18.
 */
public interface AgentService {

    Long createAgent(Connection connection, Agent agent);

    Long readAgent(Connection connection, Agent agent);

    Boolean updateAgent(Connection connection, Agent agent);

    Boolean deleteAgent(Connection connection, Long agent_id);

    Integer totalAgents(Connection connection);

    List<Agent> getAllAgents(Connection connection);

}
