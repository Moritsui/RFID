package com._42q.springboot.rfid.middleware.model;

public class Splunk {

    private Long time;
    private String host;
    private String source;
    private String index;
    private SplunkEvent event;

    public Splunk() {
    }

    public Splunk(Long time, String host, String source, String index, SplunkEvent event) {
        this.time = time;
        this.host = host;
        this.source = source;
        this.index = index;
        this.event = event;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public SplunkEvent getEvent() {
        return event;
    }

    public void setEvent(SplunkEvent event) {
        this.event = event;
    }

}
