package com._42q.springboot.rfid.middleware.service.impl;

import com._42q.springboot.rfid.middleware.model.Antenna;
import com._42q.springboot.rfid.middleware.service.AntennaService;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by maximiliano_sandoval on 4/2/18.
 */
@Service("AntennaService")
public class AntennaServiceImpl implements AntennaService {

    private static final Logger LOG = Logger.getLogger(ReaderServiceImp.class.getName());

    public Long createAntenna(Connection connection, Antenna antenna) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO backend.antenna (name, port, dbm, reader_id, antenna_connect, antenna_active ) VALUES (?,?,?,?,?,?) RETURNING id");
            statement.setString(1, antenna.getName().toLowerCase());
            statement.setString(2, antenna.getPort());
            statement.setString(3, antenna.getDbm());
            statement.setLong(4, antenna.getReader_id());
            statement.setBoolean(5, antenna.isAntenna_connect());
            statement.setBoolean(6, antenna.isAntenna_active());

            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Create Antenna: " + e.getMessage());
        }
        return null;
    }

    public Long readAntenna(Connection connection, Antenna antenna) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT id FROM backend.antenna WHERE reader_id = ? AND  name = ?");
            statement.setLong(1, antenna.getReader_id());
            statement.setString(2, antenna.getName().toLowerCase());
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            LOG.warning("Read Antenna: " + e.getMessage());
        }
        return null;
    }

    public Boolean updateAntenna(Connection connection, Antenna antenna) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE backend.antenna SET name = ?, port = ?, dbm = ?, antenna_connect = ?, antenna_active = ? WHERE id = ?");
            statement.setString(1, antenna.getName().toLowerCase());
            statement.setString(2, antenna.getPort());
            statement.setString(3, antenna.getDbm());
            statement.setBoolean(4, antenna.isAntenna_connect());
            statement.setBoolean(5, antenna.isAntenna_active());
            statement.setLong(6, antenna.getId());
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Update Antenna: " + e.getMessage());
        }
        return false;
    }

    public Boolean deleteAntenna(Connection connection, Long antenna_id) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM backend.antenna WHERE id = ?");
            statement.setLong(1, antenna_id);
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            LOG.warning("Delete Antenna: " + e.getMessage());
        }
        return false;    }

    @Override
    public Integer totalAntennas(Connection connection) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM backend.antenna");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("count");
            }
        } catch (SQLException e) {
            LOG.warning("Total Antennas: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Antenna> getAllAntennas(Connection connection) {
        List<Antenna> antennas = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM backend.antenna");
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()) {
                Antenna antenna = new Antenna();
                antenna.setId(resultSet.getLong("id"));
                antenna.setName(resultSet.getString("name"));
                antenna.setPort(resultSet.getString("port"));
                antenna.setDbm(resultSet.getString("dbm"));
                antenna.setReader_id(resultSet.getLong("reader_id"));
                antenna.setAntenna_connect(resultSet.getBoolean("antenna_connect"));
                antenna.setAntenna_active(resultSet.getBoolean("antenna_active"));
                antennas.add(antenna);
            }

            return antennas;
        } catch (SQLException e) {
            LOG.warning("Get all antennas " + e.getMessage());
        }
        return null;
    }

    @Override
    public Antenna getAntenaById(Connection connection, Long antenna_id) {
        Antenna antenna = new Antenna();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT FROM backend.antenna WHERE id = ?");
            statement.setLong(1, antenna_id);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()) {
                antenna.setId(resultSet.getLong("id"));
                antenna.setName(resultSet.getString("name"));
                antenna.setPort(resultSet.getString("port"));
                antenna.setDbm(resultSet.getString("dbm"));
                antenna.setReader_id(resultSet.getLong("reader_id"));
                antenna.setAntenna_connect(resultSet.getBoolean("antenna_connect"));
                antenna.setAntenna_active(resultSet.getBoolean("antenna_active"));
            }
            return antenna;
        } catch (SQLException e) {
            LOG.warning("Get all antennas " + e.getMessage());
        }
        return null;
    }

}
