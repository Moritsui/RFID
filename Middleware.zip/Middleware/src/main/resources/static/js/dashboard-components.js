/**
 * Created by maximiliano_sandoval on 3/14/18.
 */
$(document).ready(function() {

    //DataTables
    $('#resources-table').dataTable({
        "lengthMenu": [[10, 20, -1], [10, 20, "All"]]
    });

    //Tooltip
    $('[data-toggle="tooltip"]').tooltip();

    //Popover
    $('.server-status-toggle-popover').popover();


});