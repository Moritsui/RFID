var poiContainer,
theBody,
closeAll,
PointsOfInterest = {

	settings: [{
		id: "",
		messagePosition: "top",
		message: "Here the message"
	}],
	
	//kick things off
	init: function() {
		
		//Scrolls to top
		window.scrollTo(0, 0);
		theBody = document.getElementsByTagName('body')[0];
		closeAll = document.createElement('div');
		closeAll.className = 'close-poi';
		closeAll.innerHTML ='Remove hints';
		theBody.insertBefore(closeAll, theBody.lastChild);
		
		var scope = this;
		closeAll.onclick = function(){ scope.removesAll(this) };
		
		//thePoint.onclick = function(){ scope.pointActions(this) };
		
		for(var i = 0; i < this.settings.length; i++){
			var theElement = document.getElementById(this.settings[i].id);
			var thePositions = this.getPosition(theElement);
			this.createPoint( this.settings[i].id, thePositions, i, this.settings[i].messagePosition, this.settings[i].message );
		}
		$('[data-toggle="popover"]').popover();
	},
	
	//Gets x and y of the element  
	getPosition: function ( el ){
	  	var _x = 0;
		var _y = 0;
		while( el && !isNaN( el.offsetLeft ) && !isNaN( el.offsetTop ) ) {
		    _x += el.offsetLeft - el.scrollLeft;
		    _y += el.offsetTop - el.scrollTop;
		    el = el.offsetParent;
		}
		return { top: _y, left: _x };
	},
	
	//Creates element
	createPoint: function ( theId, thePositions, i, position, message ) {
	  //console.log("The id: " + theId + ", The top position is:" + thePositions.top, ", The left position is: " + thePositions.left );
	  //Creates the point
	  var thePoint = document.createElement('div');
	  thePoint.id = 'point-' + i;
	  thePoint.className = 'the-point';
	  theBody.insertBefore(thePoint, theBody.lastChild);
	  thePoint.style.top = thePositions.top + 'px';
	  thePoint.style.left = thePositions.left + 'px';
	  thePoint.setAttribute("data-toggle", "popover");
	  thePoint.setAttribute("data-placement", position);
	  thePoint.setAttribute("data-content", message);
	  
	  //Point events
	  var scope = this;
	  thePoint.onclick = function(){ scope.pointActions(this) };
	},
	
	//Element onClick actions
	pointActions: function (el){
		//Validates if the point has the class "point-open" assigned
	  if ( (' ' + el.className + ' ').replace(/[\n\t]/g, ' ').indexOf(' point-open ') > -1 ){
	  	  //If this is the last element inside the container
		  var remaminigPoints = document.getElementsByClassName('the-point').length;
		  if(remaminigPoints == 1){
			  //Removes the removeAll button
			  theBody.removeChild(el);
			  theBody.removeChild(closeAll);
		  }else{
		  	  //Just removes the current element
			  theBody.removeChild(el);
		  }
	  }else{
		  //Just remove the current element
		  el.className += ' point-open';
	  }
	},
	
	removesAll: function(el){
		var remainingElements = document.getElementsByClassName('the-point');
		el.parentNode.removeChild(el);
		while(remainingElements.length > 0){
			remainingElements[0].parentNode.removeChild(remainingElements[0]);
		}
	},
	
	//Adjust point onResize
	adjustPoints: function(){
		//Scrolls to top
		window.scrollTo(0, 0);
		var remainingElements = document.getElementsByClassName('the-point');
		for(var i = 0; i < remainingElements.length; i++){
			var theElement = remainingElements[i];
			var theElementId = theElement.id;
			var theElementArray = theElementId.split('-');
			var theElementIndex = parseInt(theElementArray[1]);
			//if(!isNaN(theElementIndex)){
				var referenceId = this.settings[theElementIndex].id;
				var referenceEl = document.getElementById(referenceId);
				var thePositions = this.getPosition(referenceEl);
				
				theElement.style.top = thePositions.top + 'px';
				theElement.style.left = thePositions.left + 'px';
				if(theElement.className == 'the-point point-open'){
					theElement.className = 'the-point';
					theElement.click();
					theElement.className = 'the-point';
				}
			//}
		}
		//$('.popover').popover('hide');
	}
}
// Avoids calling the resize function multiple times
function debounce(func, wait, immediate) {
	var timeout;
	return function() {
		var context = this, args = arguments;
		var later = function() {
			timeout = null;
			if (!immediate) func.apply(context, args);
		};
		var callNow = immediate && !timeout;
		clearTimeout(timeout);
		timeout = setTimeout(later, wait);
		if (callNow) func.apply(context, args);
	};
};

var myEfficientFn = debounce(function() {
	//console.log('end resizing');
	PointsOfInterest.adjustPoints();
}, 250);

window.addEventListener('resize', myEfficientFn);

