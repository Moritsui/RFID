    $(document).ready(function () {
      console.log('iniciamos!')
      // if () {
      //   $("#miId").css("background-color", "red");
      // }
      $('#mytable tr').each(function () {
        console.log($(this).find(".claseFecha").html());
        var fechaTag = $(this).find(".claseFecha").html();

        var d1 = fechaTag;
        var d2 = new Date($.now());
        console.log(new Date(d1) + ' ?? ' + new Date(d2))



        if (new Date(d1) < new Date(d2)) {
          $(this).css("background-color", "red");
        }
      });


      setTimeout(function () {
        window.location.reload(1);
      }, 5000);

    });