/**
 * Created by maximiliano_sandoval on 3/7/18.
 */

function doChange() {
    $('#terms').fadeOut(500, function(){
        $('#terms').hide();
        $('#access').fadeIn(500);
    });
};